import React from 'react'
import './Card2.css'

const Card2 = () => {
  return (
    <>
    <div className="card-card2">
        <h2>Heading of your choice</h2>
        <div className="item-card2">
        <img src="https://m.media-amazon.com/images/I/714gdRQ2pJL._AC_SY400_.jpg" alt="img1" />
        <img src="https://m.media-amazon.com/images/I/714gdRQ2pJL._AC_SY400_.jpg" alt="img1" />
        <img src="https://m.media-amazon.com/images/I/714gdRQ2pJL._AC_SY400_.jpg" alt="img1" />
        <img src="https://m.media-amazon.com/images/I/714gdRQ2pJL._AC_SY400_.jpg" alt="img1" />
        </div>
    </div>
    </>
  )
}

export default Card2